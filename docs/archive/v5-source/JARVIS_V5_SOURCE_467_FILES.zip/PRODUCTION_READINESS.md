---
title: "Release Gates and Evidence Ownership"
document_id: "PRODUCTION_READINESS"
status: "draft"
authority_class: "protected"
owner_role: "release_operator"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

This is a reusable gate specification, not a pre-checked release report. Instantiate templates/release-record.json for each release and name a verifier, timestamp, tested SHA, result and evidence for each applicable gate. The first external writer waits for the writer gates, not for the final roadmap mission.

| Gate | Accountable role | Required evidence |
| --- | --- | --- |
| Governance promotion | governance_reviewer and owner | Exact-head trusted gate result, key custody and required-check settings |
| Repository integrity | release_operator | Preserved history, active contract map, clean integration diff |
| Identity | security_reviewer | Cross-owner, stale-session, stolen/revoked-device and CSRF/step-up tests |
| Brain and context | test_evals | Actual assembled prompt digest, deterministic and judgment evaluation reports |
| Spending | backend_implementer | Durable atomic reservations, missing-usage fail-closed and parallel job tests |
| External writes | executor_engineer | Snapshot binding, epoch checks, dispatch ambiguity and reconciliation |
| Stops | release_operator | Independent cloud/local stop drills at deployed revision, including queued and in-flight effects |
| Leases | security_reviewer | Typed scope, finite expiry, use limits, renewal and revocation tests |
| Privacy | integration_specialist | Source-scoped consent, retention, deletion/export and no-secret logs |
| Recovery | release_operator | Backup restore, offline replay and no duplicate effects |
| UI approvals | frontend_implementer | Canonical display and payload-edit invalidation, accessibility and step-up |
| Operational ownership | owner | Enabled capabilities, budget profile, notification policy, unresolved limits |

“Not applicable” requires the disabled capability and evidence of non-exposure. “Tests written” differs from “tests passed”. Never replace an unexecuted drill with an unchecked box whose title sounds reassuring.
