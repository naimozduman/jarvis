---
title: "Canonical Data Model V5"
document_id: "docs::DATA_MODEL"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Canonical data model

JARVIS Core uses PostgreSQL/Neon as canonical durable state. Domain apps may remain canonical for their high-resolution domain records, linked to Core through source references and versioned contracts.

A vector index, model conversation, Convex document, browser session, or external agent memory is never a replacement for canonical state.

## Existing canonical areas

Preserve the existing schema and migrations for:
- owner/identity/device/session boundaries,
- conversations/messages/attachments/source links,
- events and processing attempts,
- jobs and executions,
- commitments/reminders/day plans,
- proposed actions/policy/approvals/executions/results,
- audit,
- constitution,
- structured memory,
- Brain requests, context manifests, model runs, decisions and evidence,
- outbound delivery state.

Existing migrations and their semantics remain authoritative implementation evidence.

## V3 conceptual additions

Future migrations should add only when the corresponding phase begins.

### Procedural skills
A skill record represents a reviewed reusable procedure:
- skill ID/version,
- purpose and domain,
- instructions or structured steps,
- source executions/evidence,
- confidence/status,
- required capabilities,
- safety notes,
- last verified time,
- supersession.

A skill never grants authority.

### World State
Ephemeral owner/device context:
- location/place class,
- travel/driving,
- current calendar block,
- foreground app/category,
- device availability,
- battery/connectivity,
- headphones/media,
- active workout,
- other time-bounded context.

World State expires unless promoted through a durable policy.

### Life Ledger
Historical events/episodes:
- location episodes,
- travel,
- app/work sessions,
- workouts,
- meals,
- media,
- conversations/call summaries,
- purchases/bills,
- calendar activity,
- JARVIS decisions/interventions.

Ledger events are history, not automatically “facts about the owner.”

### Journal
Owner-authored subjective reflection, kept distinct from inferred emotion.

### Capabilities and authority
- registered capabilities,
- authority leases,
- action-specific approval references,
- reversibility/risk metadata,
- executor registrations.

### First-party apps
- app registrations/manifests,
- source records/references,
- sync cursors,
- event schema versions,
- app health,
- command acknowledgements.

### Agent jobs
- worker/runtime selection,
- scoped context manifest,
- budgets,
- capability scope,
- checkpoints,
- artifacts,
- result evidence.

## Epistemic typing

Facts, preferences, observations, hypotheses, journal content, ledger history, and procedures remain distinct. Promotion between types is explicit and auditable.

## Time

Use UTC for instants. Retain source timezone and local-date semantics where they matter. Scheduling uses the owner’s IANA timezone at the decision boundary.

## Provenance

Derived records retain source IDs, timestamps, confidence, freshness, sensitivity, and content hashes where appropriate.

## Deletion

Provenance enables source-scoped deletion. A derived record must not survive as an unlabeled “fact” after its only source is deleted.
