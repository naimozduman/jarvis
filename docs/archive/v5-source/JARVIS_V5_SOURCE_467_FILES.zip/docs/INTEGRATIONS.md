---
title: "Integration Architecture V5"
document_id: "docs::INTEGRATIONS"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Connector standard

Every provider adapter implements the same lifecycle where applicable:

- connect/enroll,
- disconnect/revoke,
- refresh authorization,
- ingest webhook,
- sync,
- reconcile,
- health/status,
- normalize to Core contracts,
- expose capabilities.

## Connector is not product logic

Provider-specific code translates external behavior. It does not decide JARVIS goals, memory, accountability, or authority.

## Read before write

Start with read-only. Add writes only after:
- capability registration,
- policy/risk review,
- approval/lease design,
- idempotency,
- verification,
- reconciliation,
- audit,
- kill switch.

## Provider data

Track:
- source ID,
- provider account,
- freshness,
- last sync,
- authorization status,
- schema/version,
- safe error state.

## Webhooks

Verify authenticity before trusting content. Persist accepted events before expensive work.

## Reconciliation

Webhooks are hints, not complete truth. Important providers require scheduled or on-demand reconciliation.

## External content

Treat provider content as untrusted model input.

## First-party apps

First-party app connectors use the same discipline but may use a tighter SDK and owner-controlled authentication.
