---
title: "Model Runtime V5"
document_id: "docs::MODEL_RUNTIME"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Model neutrality

JARVIS identity and memory do not live in a model provider.

`ModelGateway` is provider-neutral and returns strict structured output or a safe failure.

## Logical routes

Use logical routes such as:
- `fast`: low-cost/low-latency classification and simple reasoning,
- `standard`: normal JARVIS decisions,
- `deep`: complex planning/research decisions,
- `local_private`: sensitive/private fallback where supported,
- `realtime_voice`: selected speech-to-speech or streaming path.

Concrete model IDs are configuration and should be reviewed independently from architecture.

## Router

Routing considers:
- task complexity,
- structured-output/tool needs,
- privacy class,
- latency,
- context size,
- current provider health,
- budget.

The router does not grant capabilities.

## State

Provider conversation IDs and hidden state are disposable. Canonical continuity comes from ContextManifest and durable state.

## Telemetry

Record safe:
- route,
- provider/model ID,
- reasoning/effort setting,
- latency,
- token usage where supplied,
- configured cost estimate,
- validation status,
- error class.

Do not log prompts, credentials, raw provider responses, or hidden reasoning.

## Failure

Invalid schema, provider error, budget violation, or unavailable route produces no action. Preserve the event and use a safe fallback/retry path.

## Testing

Provider-free fake gateways remain required. Live model probes are gated and separately observable.

## V5 accounting and provenance gate

“Token usage where supplied” applies to telemetry fields, not permission to spend without accounting. Every paid call requires conservative pre-call reservation and a reconcilable receipt. Unknown or stale paid accounting blocks new billable work. COST_AND_MODEL_POLICY.md owns the rule. Preserve the existing ModelBudgetGuard and test each caller plus concurrent reservations before expansion.

The candidate design adds registered module content digests and ordered assembly provenance. Existing promptVersion fields remain intact. No generated preview is active until a versioned loader migration and behavioral evaluation pass. A fallback must preserve required privacy, output compatibility and authority, not merely produce text.
