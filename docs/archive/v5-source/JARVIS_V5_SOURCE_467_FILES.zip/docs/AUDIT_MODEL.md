---
title: "Audit Model V5"
document_id: "docs::AUDIT_MODEL"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Purpose

JARVIS should answer “why did you do this?” from durable evidence.

## Append-only principle

Meaningful decisions and side effects append audit records. Corrections create new linked entries instead of rewriting history.

## Audit record

Record safe metadata for:
- owner,
- actor type/ID,
- trigger,
- target type/ID,
- correlation/causation,
- policy result,
- authority source,
- approval reference,
- capability,
- model/prompt versions when relevant,
- executor,
- result,
- verification,
- rollback/reconciliation status,
- timestamps,
- source references.

## Agent work

Agent jobs log:
- assigned goal,
- scoped capabilities,
- context manifest reference,
- budgets,
- checkpoints,
- artifacts,
- proposed actions,
- final evidence.

Do not store hidden model reasoning.

## Privacy

Audit stores references, hashes, safe categories, and bounded summaries instead of full private payloads where possible.

Never include credentials, full intimate messages, raw health/finance records, private attachment bodies, or chain-of-thought.

## Explainability

A future control-center view should link:
trigger -> selected context -> decision -> policy -> approval -> execution -> verification -> memory write.

This is operational provenance, not a generated story.

## V5 evidence custody
Audit model/agent decisions, mode switches, lease creation/use/revocation, enrollment, budget reservation/overrides, stops and outcome reconciliation. Store prompt content fingerprints and source versions, not hidden reasoning. A hash chain detects local sequence tampering only when periodic anchors are held independently. Do not claim tamper-proof audit from a hash chain editable by the same database administrator. Audit-watch and independent anchors are a later implementation gate before unattended high-impact expansion.
