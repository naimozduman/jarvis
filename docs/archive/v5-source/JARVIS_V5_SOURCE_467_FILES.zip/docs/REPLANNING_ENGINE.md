---
title: "Replanning Engine V5"
document_id: "docs::REPLANNING_ENGINE"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Goal

Replanning responds to reality without treating disruption as automatic failure.

## Plan data

Blocks carry:
- fixed/flexible/optional class,
- commitment link,
- duration/minimum duration,
- earliest/latest bounds,
- dependencies,
- travel/preparation,
- priority/consequence,
- completion/movement state,
- source and placement reason.

## Deterministic constraints

Code validates:
- owner/day scope,
- time ordering,
- windows,
- minimum duration,
- overlap,
- dependencies,
- protected anchors,
- travel/preparation.

Omitting a protected anchor never means delete it.

## Recovery order

1. protect fixed external anchors,
2. protect high-consequence commitments,
3. respect hard overrides,
4. recalculate remaining windows,
5. shrink/move flexible work,
6. drop optional work explicitly,
7. show tradeoffs.

## Model role

The model chooses/explains among valid options. It does not invent impossible scheduling space.

## State

Applied plan changes go through canonical action/policy/audit paths.
