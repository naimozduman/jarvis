---
title: "Durable Outbound Delivery"
document_id: "docs::OUTBOUND_DELIVERY"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Boundary

Brain output is persisted before transport. The Brain never directly calls WhatsApp, email, push, or another external channel.

## Flow

`response/reminder -> policy -> canonical outbound delivery -> opaque wakeup -> canonical lease -> transport adapter -> provider result -> reconciliation/audit`

## States

At minimum:
- pending,
- leased,
- sent,
- delivered,
- read,
- failed_retryable,
- failed_terminal,
- reconciliation_required,
- expired/cancelled where modeled.

## Idempotency

Intent projection uses an owner-scoped deterministic operation key. Transport calls begin only after acquiring a canonical lease.

A duplicate wakeup cannot create a duplicate send.

## Uncertain results

If a provider may have accepted a send but the response was lost, do not blindly resend. Mark reconciliation required.

## Freshness

Conversation replies, reminders, and critical alerts have different freshness/attempt policies. Reconnect does not resurrect expired messages.

## Proactive delivery

Proactive messages use the same pipeline. Quiet mode suppresses a delivery attempt, not the underlying commitment or state.

## Verification

Provider receipt/status is evidence. Where delivery/read receipts are unavailable, report the strongest known state rather than “delivered.”
