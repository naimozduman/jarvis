---
title: "Offline Transport and Reconnect"
document_id: "docs::OFFLINE_TRANSPORT"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Rule

Channel loss is not brain loss.

Canonical responses, reminders, commitments, and jobs survive a disconnected bridge or messaging provider.

## Current local-bridge model

Convex exposes only opaque pending signals. The local bridge requests a fresh canonical Neon lease from Vercel before receiving private content.

Convex does not store:
- message text,
- owner phone/JID,
- Brain context,
- memory,
- credentials.

## Lease safety

A lease is short, random-token bound, owner/delivery/bridge scoped, and checked again on result callback.

## Reconnect

On reconnect:
1. bridge sees opaque signal,
2. Vercel checks freshness/eligibility,
3. only eligible work receives a lease/content,
4. expired work remains expired.

## Unknown send

Lease expiry after a possible provider send means reconciliation required. Automatic resend is unsafe.

## Dependency failures

- Convex down: Neon state remains correct.
- Neon down: no send.
- local bridge down: no content leaves cloud; work waits/ages.
- Evolution down: explicit failure, never fake success.
