---
title: "WhatsApp Risk Register"
document_id: "docs::WHATSAPP_RISK_AND_RECOVERY"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Risks

## Unofficial/proxy transport risk
Evolution/Baileys behavior, WhatsApp enforcement, or provider changes may break sessions.

Mitigation: dedicated number, local isolation, immutable reviewed build, version gate, replaceable transport contract.

## Duplicate send
Retry after ambiguous provider result may send twice.

Mitigation: canonical lease/idempotency, reconciliation-required state.

## Wrong sender accepted
Provider identity formats are complex.

Mitigation: server-side owner enrollment, strict direct-message allowlist, rejected alias/group traffic.

## Session compromise
Local session files grant channel access.

Mitigation: local-only protected storage, no model/log exposure, revocation/re-pair procedure.

## Late stale reminder
Bridge reconnect may surface old work.

Mitigation: freshness checked in canonical Neon at lease time.

## Core/channel confusion
A healthy API may be misreported as WhatsApp connected.

Mitigation: separate Core readiness and transport health.

## Provider obsolescence
Evolution might become unacceptable.

Mitigation: Brain and delivery contracts remain provider-neutral so another WhatsApp path or another surface replaces it.
