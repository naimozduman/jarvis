---
title: "Evolution Integration Boundary"
document_id: "docs::EVOLUTION_INTEGRATION"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Role

Evolution is a replaceable WhatsApp provider adapter behind the local bridge.

It owns transport/session mechanics only.

## Adapter duties

- connection/pairing/status,
- authenticated webhook verification,
- strict event parsing,
- owner identity normalization,
- send call,
- provider result normalization,
- health reporting.

## Adapter prohibitions

It cannot:
- choose canonical owner,
- read/write arbitrary Core tables,
- call the Brain,
- decide policy,
- store JARVIS memory,
- bypass outbound leases.

## HTTP routes

Provider-specific route details must be verified from the exact approved Evolution source before changing the adapter. Do not assume a prior endpoint list remains current.

## Webhook auth

Use the exact authentication mechanism supported by the reviewed build. Verify before parsing untrusted payload into trusted transport state.

## Configuration

Sensitive values stay local/server-side:
- instance identity,
- owner phone/LID enrollment,
- base URL,
- API key,
- webhook secret,
- reviewed build ID,
- WhatsApp-library version,
- immutable image digest.

## Dedicated number

V1 uses the dedicated JARVIS number only.
