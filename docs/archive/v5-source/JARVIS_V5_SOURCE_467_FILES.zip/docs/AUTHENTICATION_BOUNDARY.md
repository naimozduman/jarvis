---
title: "Identity Enrollment and Per-Action Authentication"
document_id: "docs::AUTHENTICATION_BOUNDARY"
status: "draft"
authority_class: "protected"
owner_role: "security_reviewer"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Single owner, server-bound principal

Client-supplied owner IDs are consistency fields, not authentication. Resolve owner from trusted session/service identity and compare every target owner. A bridge token grants only its configured bridge/connection scope, not owner-facing approval authority. Cross-owner negative tests apply even in a one-owner database.

## Initial owner bootstrap

Do not bootstrap owner identity from the first caller. An operator-controlled one-use enrollment secret is installed out of band, with short expiry and no logging. Establish the first passkey over the first-party origin, verify WebAuthn challenge, RP/origin, signature and user verification, consume the bootstrap secret, and disable public enrollment. Recovery uses owner-controlled offline recovery material, revokes old sessions and is audited. A new surface does not create a second owner.

## WhatsApp binding

1. Recently reauthenticated owner opens the first-party enrollment view.
2. Server creates an unpredictable, one-use challenge tied to owner/session/connection with expiry.
3. Owner sends it from the intended personal sender to the dedicated JARVIS transport account. Do not pair the personal account to the automation bridge.
4. Local adapter verifies provider ingress and challenge observation. Enrollment reconciles both authenticated first-party session and verified sender challenge, not an arbitrary alias field.
5. Store an opaque identity reference. Derive stable local references with versioned HMAC using a secret identity key, or use random IDs plus encrypted mapping. Unsalted phone hashes are not anonymization. Keep keys separate from the database, version normalization and support rotation.
6. Enroll LID aliases only through separately verified linkage. Audit safe references and enrollment method, never raw identifiers or challenge secrets.

## High-impact resolver

HIGH_IMPACT approvals and lease enrollment require fresh step-up, proposed maximum age 5 minutes. Validate owner, device/session, method, challenge and exact action. Possession of an unlocked WhatsApp thread is insufficient. UI and API both enforce the rule. A JSON authMethod field alone is not evidence.

## Unavailable owner

Absence, travel, missed heartbeat or device outage never grants authority. Preserve read/monitor/draft and bounded internal work. Defer external work without valid specific authority. Recovery and deliberate awake override use a first-party control, not a model's inference that the owner seems present.
