---
title: "Deterministic Policy Matrix"
document_id: "docs::POLICY_MATRIX"
status: "draft"
authority_class: "protected"
owner_role: "security_reviewer"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Policy cannot be negotiated by the model

The canonical finance prohibition is INV-FINANCE-001 in governance/INVARIANTS.json. No alternative wording in prompts, schemas or capability manifests grants an exception.

| Class | Baseline result | Additional checks |
| --- | --- | --- |
| READ | Allow only verified owner, purpose and source scope | Sensitivity, freshness, allowed destination and resource admission |
| LOW_RISK_INTERNAL | Allow registered reversible internal effect | Exact contract, evidence, owner, idempotency and audit |
| CONTROLLED_WRITE | Approval or explicitly enrolled finite lease | Target/account/type bounds, use reservation, expiry, recheck, verification |
| HIGH_IMPACT | Action-specific trusted approval and fresh step-up | Never standing lease, exact snapshot, no unattended Night Mode |
| PROHIBITED | Deny | No approval or model mode overrides denial |

Finance movement, purchases and account mutations remain prohibited in this candidate baseline. Read-only finance observations do not get classified by a broad `finance.*` prefix alone in future registries; inspect the existing runtime before changing it.

Unknown capability, owner mismatch, missing authority, changed payload, revoked permission, invalid schema, expired job/action, unsafe egress, failed resource admission or active kill domain denies dispatch. Resource admission runs before paid model/tool calls as well as before effectful execution. A cheap model is not a bypass.

Policy inputs are versioned. Bind authorization to policy version and kill epoch. Changes to the matrix, its code implementation, risk classification, test baseline or trusted validator require protected promotion. Runtime behavior is tested from registered semantics, not grepped prose.
