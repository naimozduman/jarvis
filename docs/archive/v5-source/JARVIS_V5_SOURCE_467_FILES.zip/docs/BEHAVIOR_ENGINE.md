---
title: "Behavior Engine V5"
document_id: "docs::BEHAVIOR_ENGINE"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Purpose

Adapt intervention tactics to observed behavior without inventing behavioral science or rewriting owner values.

## Registry

Interventions are versioned, reviewable definitions with:
- purpose,
- triggers,
- contraindications,
- required context,
- examples,
- cooldown,
- expected success/failure signals,
- cost/interruptiveness.

Examples include minimum viable action, environment preparation, friction reduction, implementation intentions, decomposition, starting ritual, time boxing, recovery after lapse, progress visibility, and bounded choice.

## Selection

Deterministic eligibility narrows the candidates. The model may choose among eligible interventions and adapt wording.

## Learning

Record outcomes as associations, not causal proof. Avoid turning a few outcomes into permanent psychological claims.

## Personality learning

Delivery preferences such as length, directness, humor, strictness, praise style, and reminder density require repeated evidence or owner review. They remain editable/resettable.

## Safety

No shaming, humiliation, manipulation, or clinical diagnosis. Behavior signals never grant executor authority.
