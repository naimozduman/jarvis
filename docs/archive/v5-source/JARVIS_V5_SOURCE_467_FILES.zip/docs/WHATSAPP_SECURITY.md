---
title: "WhatsApp Security"
document_id: "docs::WHATSAPP_SECURITY"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Admission

Only authenticated transport events resolving to the enrolled owner may produce a Brain turn in V1.

Rejected traffic produces a safe redacted record and no memory, commitment, plan, reminder, or action.

## Version gate

Evolution/Baileys is fail-closed until `EVOLUTION_VERSION_GATE.md` is reverified against current releases/advisories and an immutable build is approved.

Do not rely on old header/version strings as evidence.

## Secrets

Never log or expose:
- Evolution API key,
- webhook signing/JWT material,
- session/auth files,
- pairing QR/code,
- raw provider payloads,
- raw JIDs,
- private message bodies in telemetry.

## Inbound content

Even owner messages may contain quoted/external content. External content remains untrusted data.

## Outbound

Only canonical, owner-bound deliveries reach the bridge. The model cannot choose arbitrary WhatsApp targets.

## Primary account

Do not connect the owner's primary personal WhatsApp account. Use the dedicated JARVIS number.

## Pairing

Pairing is an operator procedure. QR/pairing material never enters Git, logs, screenshots intended for sharing, or model context.
