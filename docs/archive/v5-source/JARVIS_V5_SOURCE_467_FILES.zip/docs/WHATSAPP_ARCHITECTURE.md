---
title: "WhatsApp Architecture V5"
document_id: "docs::WHATSAPP_ARCHITECTURE"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Boundary

WhatsApp is a surface/transport. It never owns JARVIS state, memory, Brain logic, or authority.

Evolution is one replaceable implementation behind a provider-neutral messaging boundary.

## Current path

```text
WhatsApp
 -> local Evolution
 -> local bridge normalization
 -> authenticated Vercel ingress
 -> canonical Neon event
 -> opaque Convex wakeup
 -> Brain/policy
 -> canonical response + outbound delivery
 -> opaque Convex signal
 -> local bridge requests canonical lease/content
 -> Evolution send
 -> result back to Neon
```

Private message content does not belong in Convex.

## Ownership

- Neon: conversations, normalized messages, Brain state, delivery intents/results.
- Evolution: WhatsApp session/auth/infrastructure state only.
- local bridge: private transport execution boundary.
- Vercel: canonical request-scoped processing.
- Convex: opaque wakeup metadata.

## Inbound

Only verified owner direct-message traffic enters the Brain in V1.

Webhook/provider payload never selects canonical owner identity.

## Outbound

The model does not supply phone/JID, endpoint, or credential. Canonical owner-target binding and deterministic policy choose the destination.

## Failure

Evolution loss means channel loss. It must not erase canonical state. Re-pairing does not create a new JARVIS identity.
