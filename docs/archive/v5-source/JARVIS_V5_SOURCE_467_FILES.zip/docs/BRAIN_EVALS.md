---
title: "Brain Evaluation Coverage"
document_id: "docs::BRAIN_EVALS"
status: "draft"
authority_class: "protected"
owner_role: "test_evals"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Preserve the existing suite

The actual repository CI observed at the source checkpoint explicitly runs brain:evals, and its Vitest configuration also discovers Brain .test.ts files. V5 does not remove or duplicate that suite to fix a nonexistent omission.

## V5 additions

Map invariant IDs to tests for facts versus hypotheses, epistemic state versus sensitivity, ignored-message handling, meaningful commitment completion, owner overrides, source coverage, context budgeting, prompt-content fingerprints, malformed output and uncertainty. Judgment cases test useful replanning, interruption selection, source reconciliation and grounded conclusions across domain apps.

The supplied eval catalog records required future cases as required_unimplemented unless an actual implementation test was observed. It never marks a behavior covered because a filename is suggested. Known baseline tests are listed with their checkpoint and must be re-run locally.

Refer to EVALS_AND_ACCEPTANCE for incident linkage, fixture-change protection and evidence custody. Code-format coverage and green historical regressions are not proof a new model follows the required judgment behavior.

## V5 selected freshness and result provenance

promotion_evidence.py reads the BASE implementation map and eval catalog. Every affected required suite needs authenticated successful platform evidence and a signed fresh exact-head coverage review. Missing application test mappings fail instead of inventing coverage. Unrelated future planned suites do not block. New control/schema activation adds its trusted requirements. See docs/VERIFICATION_EVIDENCE.md for exact formats, failure cases and installed-runner limits. A declaration in impact.py or a local result in validation/ is not authenticated promotion evidence.
