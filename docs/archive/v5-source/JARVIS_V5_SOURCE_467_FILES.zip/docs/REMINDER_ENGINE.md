---
title: "Reminder and Ghosting Engine V5"
document_id: "docs::REMINDER_ENGINE"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Reminder model

A reminder is durable state with purpose and follow-up logic, not a notification fire-and-forget.

## Trigger types

- fixed time,
- relative to event,
- before/after deadline,
- contextual,
- conditional,
- recurring,
- until completed,
- follow-up,
- open-loop,
- escalating.

## Delivery

Reminder eligibility is separate from channel delivery. If WhatsApp is offline, the reminder remains open while delivery follows freshness policy.

## Ghosting

Explicit states include:
- waiting,
- follow-up scheduled,
- escalated,
- replan needed,
- expired without completion,
- needs review.

No-response does not complete anything.

## Proactive budget

Normal messages are grouped and budgeted. Critical items may bypass the budget under explicit policy. JARVIS should prefer one useful grouped brief over several fragmented pings.

## Completion

A reminder closes because the underlying requirement is completed, dismissed under valid policy, expired according to its semantics, or explicitly cancelled. Channel silence alone never closes it.
