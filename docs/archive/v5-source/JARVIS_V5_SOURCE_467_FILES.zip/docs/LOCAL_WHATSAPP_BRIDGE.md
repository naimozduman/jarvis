---
title: "Local WhatsApp Bridge"
document_id: "docs::LOCAL_WHATSAPP_BRIDGE"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Purpose

The local bridge keeps raw WhatsApp session state and Evolution execution off Vercel/Convex.

## Outbound

`opaque signal -> bridge -> authenticated lease request -> Neon eligibility/lease -> private intent -> local send -> result -> Neon`

Convex never sees private content.

## Inbound

`local provider event -> local strict normalization -> authenticated Vercel ingress -> canonical event -> opaque job wakeup`

## Lease

The server returns delivery content only after:
- bridge authentication,
- owner/connection match,
- freshness,
- canonical conditional lease,
- attempt/reconciliation checks.

The lease token is short-lived and scoped.

## Uncertainty

Provider exception after a possible send becomes reconciliation-required. The bridge never guesses “not sent” and retries on its own.

## Exposure

Default local-only. No public tunnel is a product requirement.

## Secrets

Evolution API/session/JID/QR material remains local and out of Convex, browser code, and model context.
