---
title: "Budget Admission and Model Routing"
document_id: "docs::COST_AND_MODEL_POLICY"
status: "draft"
authority_class: "protected"
owner_role: "backend_implementer"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Spend requires admission before work

The existing repository has a ModelBudgetGuard. Preserve it. V5 does not claim budgets are absent because source is outside this overlay. J5-M02 classifies the subsystem and J5-M05 traces every caller and the actual accounting source, including concurrency and process restarts.

## Owner decision versus proposal

A prior owner conversation mentioned an initial $50 AI budget. The $60 plan in earlier assistant replies was not approved. governance/OWNER_DECISIONS.json preserves these distinctions. templates/policies/runtime-budget.proposed.json offers a $50 monthly / $5 daily / $1 default-job profile and a $2 optional-analysis confirmation threshold. They are proposals. `enabled` is false and `ownerApprovalRef` is null. No .env overwrite is included.

## Required admission contract

Use integer USD micro-units. Atomically reserve the conservative upper bound across job, daily, monthly and provider budgets before each metered call. All concurrent workers share durable reservation state. Include retries, background jobs, voice/STT/TTS and tool charges. Monthly period uses an explicit billing timezone; owner-local quiet-hour policy is separate. An upper bound needs a verified rate card and provider-specific accounting semantics.

Settle reservations with exact receipt or conservatively retained maximum. Unknown cost is not zero. Requests with unknown outcomes retain reservations until reconciliation. Do not blindly release after timeout or restart. Reject new paid work if no safe bound or reconcilable receipt exists. Provider-side limits are defense in depth; verify whether they halt or only alert.

## Exhaustion

At the hard cap reject new paid calls, preserve durable work and defer nonurgent jobs. A deterministic status response and explicitly approved non-billable route may remain available if privacy and capability requirements hold. No paid fallback, top-up, secret budget edit or weakened receipt requirement. Re-evaluate stale jobs before resuming.

The proposed warning levels are 70% and 90%; 100% is an admission boundary. They are UX defaults, not evidence of cost saved. Productive heavy use and repeated no-progress retries are separate conditions.

## Runaway work

Every agent job declares calls, tokens/output, dollars, elapsed time and retry bounds. Repetition/no-progress trips the job breaker even with monthly money left. Fingerprint normalized operations/results and track progress tokens. Do not reattempt an uncertain side effect as a new operation key.

## Override

A temporary increase is exact-job, extra-amount and expiry bounded, recently reauthenticated, auditable and outside builder authority. Global ceiling changes need the owner policy promotion path. No blanket 24-hour delay is imposed as an unapproved personal restriction. A cooling-off feature is optional owner policy, never silently inferred from the time of day.

## Gate

Reference tests exercise reservation arithmetic and unknown accounting but are not the database implementation. Live paid expansion remains blocked until tests prove atomic multi-worker reservation, restart recovery, provider reconciliation, per-job breaker and exact-scope override on the actual gateway path.
