---
title: "WhatsApp Owner Identity"
document_id: "docs::WHATSAPP_IDENTITY"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Trusted ownership

Server-side configuration and authenticated enrollment bind the canonical owner to the dedicated JARVIS WhatsApp identity.

Never trust a provider-supplied owner ID.

## V1 accepted traffic

Owner-only direct messages.

Phone-style identifiers are normalized inside the provider adapter and compared to enrolled owner identity. LID-style identifiers require separate authenticated enrollment.

## Rejected

- groups,
- broadcasts/newsletters,
- status traffic,
- unresolved aliases,
- malformed identities,
- non-owner senders,
- provider history/protocol events as live commands.

## Privacy

Raw JIDs/phone identifiers stay inside the narrow adapter/local boundary where possible. Canonical records use opaque references/hashes.

## Future contacts/groups

Supporting other people requires a new contact/privacy model and accepted policy. Do not enable it by merely relaxing parser rules.
