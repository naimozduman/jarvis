---
title: "WhatsApp Recovery"
document_id: "docs::WHATSAPP_RECOVERY"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Recovery principle

Repair the channel without altering canonical JARVIS state.

## Connection loss

1. mark transport degraded/disconnected,
2. keep canonical deliveries/reminders intact,
3. stop requesting private delivery content while bridge/provider is unavailable,
4. restore local Evolution/bridge,
5. recheck version gate and identity,
6. reconnect/re-pair if required,
7. resume opaque signals,
8. let Neon freshness decide eligibility.

## Do not

- mark unsent work completed,
- resend uncertain sends blindly,
- recreate conversations as a new JARVIS identity,
- bypass owner identity to “get it working,”
- pair the primary personal account.

## Uncertain send

If the provider call may have started, require reconciliation before another send.

## Session loss

Evolution session loss means transport credentials were lost. JARVIS Core memory/commitments remain unaffected.

## Pairing evidence

Keep sensitive pairing artifacts local and transient. Record only safe operational status in Core.
