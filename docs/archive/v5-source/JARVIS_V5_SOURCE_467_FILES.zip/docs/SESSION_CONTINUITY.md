---
title: "One current handoff and preserved history"
document_id: "DOCS_SESSION_CONTINUITY"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-26"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# One current handoff

`governance/STATE.json` is the one mutable engineering handoff. It is descriptive only. It points to provider observations and the reconciliation map rather than duplicating their values. `docs/WORKING_STATE.md` is a generated view. The full PRD and previous chat history are not the current mission state.

Use `state.py` with an expected prior file hash. The local lock prevents cooperating sessions from silently overwriting each other. It is not distributed consensus and does not authenticate the author's claims. A stale lock requires operator inspection, not automatic deletion by a blocked agent.

Before the V5 convention is adopted, all reports go to approved scratch. After adoption, save branch/base/head, dirty files, command/evidence references, blockers and next safe step. Do not include secrets, raw personal messages or live connection strings.

Append milestone and incident evidence to the existing progress record structure. Preserve accepted old entries and migrations byte-for-byte. A newer handoff never retroactively edits history. A builder reports ready_for_verification. Only the independently trusted process issues mission completion and promotion evidence.
