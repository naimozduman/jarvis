---
title: "Accountability Engine V5"
document_id: "docs::ACCOUNTABILITY_ENGINE"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Purpose

Protect important commitments without turning JARVIS into a nag or moral judge.

## Inputs

Evaluate:
- constitutional relevance,
- commitment priority/consequence,
- deadline/time remaining,
- dependencies,
- current constraints,
- alternate windows,
- minimum acceptable version,
- previous misses,
- active hard override,
- tomorrow's protected obligations,
- current World State when relevant.

## Outcomes

- continue,
- move,
- minimum viable action,
- swap/protect another slot,
- ask one clarification,
- accept override,
- escalate reminder,
- record miss and recovery plan.

There is no “delete because owner stopped replying.”

## Challenge rule

Challenge once when a viable option remains and the owner has not issued a valid hard override.

## Completion

Completion requires evidence appropriate to the commitment. Self-report may be valid evidence for some commitments. Silence is never evidence.

## Tone

Direct, warm, concise. No shame or insult.
