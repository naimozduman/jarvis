---
title: "Evaluation Evidence and Freshness"
document_id: "docs::EVALS_AND_ACCEPTANCE"
status: "draft"
authority_class: "protected"
owner_role: "test_evals"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Green tests are necessary, not sufficient

Keep the existing test harness. Split categories in governance/EVAL_CATALOG.json: contract, deterministic policy, integration/recovery, safety/adversarial, judgment, regression and live-model compatibility. A permanently green deterministic suite is desirable, not proof of obsolescence.

## Change gate

Behavior changes identify affected invariant IDs and suites in the impact manifest. Incidents and meaningful owner corrections receive an incident ID, proposed regression/judgment scenario or a reviewed reason why automation is unsuitable. A schema formatting test cannot substitute for a judgment test.

Critical baseline tests, expected denials and evaluation thresholds are protected changes. Add coverage freely through a reviewed change, but do not delete/skip/relax a failure to finish the feature. Test output is a run artifact, not a sentence in a progress note.

## Evidence receipt

Record exact commit, trusted harness digest, suite/category, fixtures digest, model/provider/route when used, prompt content fingerprint, policy/contract versions, start/end, command exit, pass/fail counts, coverage, failures and log artifact references. Do not store hidden reasoning or raw private fixtures. Synthetic tests in this pack are not evidence of live-model behavior.

## Freshness

Re-review judgment scenarios after a model-family, prompt-assembly, capability or authority change and after relevant incidents. Quarterly coverage review is a proposed schedule once real usage begins. Track missing incident regressions, unexercised invariants, test removals, gaps in task distribution and aged judgment scenarios. Do not treat code line coverage as semantic coverage.

## External review

Candidate application code runs in unprivileged CI without deploy or owner-signing credentials. A separate trusted promotion gate checks immutable baseline rules and evidence. Separate agents improve review coverage but do not create independence if the builder controls their inputs and permissions. Required tests must actually run on the final commit before release.

## V5 selected freshness and result provenance

promotion_evidence.py reads the BASE implementation map and eval catalog. Every affected required suite needs authenticated successful platform evidence and a signed fresh exact-head coverage review. Missing application test mappings fail instead of inventing coverage. Unrelated future planned suites do not block. New control/schema activation adds its trusted requirements. See docs/VERIFICATION_EVIDENCE.md for exact formats, failure cases and installed-runner limits. A declaration in impact.py or a local result in validation/ is not authenticated promotion evidence.
