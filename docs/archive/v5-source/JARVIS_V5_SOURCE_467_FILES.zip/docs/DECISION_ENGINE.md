---
title: "Decision Engine V5"
document_id: "docs::DECISION_ENGINE"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Goal

Turn current state into safe structured proposals by combining deterministic constraints with model reasoning.

## Stages

1. identify trigger,
2. determine affected domains,
3. load source state,
4. apply hard policy,
5. decide whether reasoning is required,
6. assemble bounded context,
7. request structured decision,
8. validate schema/evidence/freshness,
9. persist decision,
10. evaluate action policy,
11. execute or request approval,
12. schedule follow-up,
13. verify and audit.

## Hard policy before model

Use deterministic code for:
- owner identity,
- finance write prohibition,
- kill switches,
- tool/capability visibility,
- protected anchors,
- stale-data thresholds,
- duplicate operations,
- active authority leases,
- constitution edit restrictions.

## Decision types

Core types:
- answer,
- capture,
- clarify,
- remind,
- replan,
- negotiate,
- summarize,
- alert,
- propose_action,
- delegate_agent_job,
- no_message.

## Deterministic planning

Lock fixed anchors and hard constraints first. Generate valid windows/options in code. Let the model compare tradeoffs, not invent physically impossible time.

## Accountability

Challenge once only when the commitment matters, a realistic alternative exists, the reason is flexible, no hard override exists, and intervention remains appropriate.

## Memory and skill candidates

A model proposes candidates. Promotion is separate:
- owner-stated facts remain source-backed,
- inferred stable claims start as hypotheses/candidates,
- preferences require repeated evidence or confirmation,
- procedures require verified successful execution/evidence.

## Safe failure

On invalid structured output, missing source, stale critical data, or provider failure:
- no executor action,
- preserve state,
- bounded retry when safe,
- ask one material clarification or report degraded status.
