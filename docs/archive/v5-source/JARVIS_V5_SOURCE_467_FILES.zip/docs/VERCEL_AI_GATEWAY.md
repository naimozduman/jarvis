---
title: "AI Gateway Boundary"
document_id: "docs::VERCEL_AI_GATEWAY"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Role

An AI Gateway is one possible model transport. It does not own JARVIS state or model identity.

## Contract

The adapter:
- receives a bounded context/request,
- uses strict structured output where supported,
- disables hosted storage when feasible,
- returns normalized usage/error metadata,
- never owns conversation continuity.

## Authentication

Gateway credentials or platform identity remain server-side. Direct-provider keys and gateway credentials are separate.

## Routing

Use logical JARVIS routes from `MODEL_RUNTIME.md`. Exact provider/model IDs require a live compatibility probe before production use.

Do not infer support for:
- structured output,
- tool use,
- context size,
- reasoning controls,
- free-tier status

from model naming alone.

## Cost policy

The former zero-cost-only admission strategy is superseded by `COST_AND_MODEL_POLICY.md`.

Still preserve:
- hard spend guards,
- explicit route configuration,
- no silent paid fallback,
- usage reconciliation,
- fail-closed handling when cost/route status is unknown.

## Compatibility test

A candidate Brain model must prove:
- exact schema compliance,
- required output size,
- stable error handling,
- acceptable latency/cost,
- idempotent replay at the JARVIS layer.

Catalog listing alone is not enough.
