---
title: "Event Model"
document_id: "docs::EVENT_MODEL"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Principle

Every meaningful observation enters JARVIS as a typed event or explicit durable state transition.

An event says what was observed, where it came from, and when. It does not silently claim the observation is a permanent fact.

## Envelope

Core fields:
- event ID,
- owner ID,
- event type,
- source,
- source event/record ID,
- occurred time,
- received time,
- schema version,
- idempotency key,
- correlation and causation IDs,
- sensitivity,
- payload hash,
- payload or source reference,
- processing state.

## Sources

Sources may include:
- WhatsApp,
- web,
- Android,
- browser,
- voice,
- Gmail,
- Calendar,
- first-party apps,
- health connectors,
- finance connectors,
- device agents,
- scheduled jobs,
- agent workers.

## Ingestion

1. authenticate source,
2. size/shape validate,
3. normalize,
4. persist immutable envelope,
5. deduplicate,
6. enqueue or schedule canonical processing,
7. acknowledge.

## App events

First-party app events identify app ID, app schema version, source record reference, and data owner. Core should ingest decision-relevant summaries rather than duplicate huge raw records by default.

## Device/world-state events

High-volume events may update ephemeral World State instead of creating permanent ledger records. Promotion policy decides what is retained.

## Event to memory

Events may support a memory candidate. They never directly rewrite constitution or durable memory merely because they occurred.

## Replay

Processing is replay-safe. Replaying an event does not create a second commitment, message, action, or external effect.
