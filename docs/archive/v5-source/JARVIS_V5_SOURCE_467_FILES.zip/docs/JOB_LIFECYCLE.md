---
title: "Durable Job Lifecycle"
document_id: "docs::JOB_LIFECYCLE"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Canonical authority

Neon owns durable job state.

The historical pg-boss runtime remains part of repository history. The active serverless topology uses Convex to wake an authenticated Vercel callback, then Vercel rehydrates and leases the canonical Neon job.

Convex never decides whether work is valid.

## Required job fields

A durable job records:
- owner,
- type,
- idempotency key,
- canonical payload/reference,
- priority,
- availability/schedule time,
- dispatch generation,
- optional latest-start deadline,
- attempt/lease state,
- maximum attempts,
- correlation/causation,
- source event,
- sanitized error/result metadata.

## Generation

A reschedule, replacement, or cancellation that invalidates previously emitted wakeups advances `dispatch_generation`.

A normal retry remains in the same generation.

Stale callbacks cannot execute a newer or cancelled instruction.

## Lifecycle

`queued -> eligible -> leased -> running -> completed`

Failure branches:
- retryable -> retry wait -> eligible,
- terminal -> terminal failed,
- uncertain external side effect -> reconciliation required,
- cancelled,
- expired before lease.

## Lease

Only canonical database state grants execution. A stale or duplicate worker cannot overwrite a newer lease/result.

## Error policy

Retry only explicitly classified transient failures. Unknown failures are terminal or review-required by default.

## Agent jobs

Long-running agent work follows the same durable lifecycle. The worker may checkpoint progress, but “agent started” is not completion.

## Completion

Completion is a canonical state transition backed by handler evidence. Silence, timeout, or lost connection never implies success.

## Deadline and lease distinctions

An optional execution deadline is the latest time a new database lease may start. It does not expire an already acquired lease, mark a commitment complete or replace outbound freshness. A null execution deadline means durable work remains eligible under its own lifecycle. Normal retry keeps dispatch generation and advances the attempt counter. Replacement, reschedule and cancellation invalidate stale callbacks through a new generation. Preserve the actual accepted ADR 0015 implementation and tests during migration.

A stalled worker is an observed liveness problem, not proof that its external effect failed. Reconciliation survives worker death and stop activation. Heartbeat windows and progress markers are registered per job type and tested against the deployed worker before unattended operation.
