---
title: "Vercel Stateless Runtime"
document_id: "docs::VERCEL_RUNTIME"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Role

The active cloud API is stateless Vercel runtime backed by canonical Neon and opaque Convex orchestration.

Vercel does not host Evolution sessions or a long-running worker loop.

## Runtime composition

Per request:
1. validate configuration,
2. create bounded database/runtime dependencies,
3. authenticate request,
4. rehydrate canonical state,
5. perform request-scoped work,
6. persist canonical result,
7. close resources.

Process memory is never required for correctness.

## Fastify

The repository uses a Vercel-compatible Fastify entrypoint with reusable inner application composition. Keep serverless capture/listener concerns outside the reusable Core API layer.

## Responsibilities

Vercel may:
- ingest authenticated/verified events,
- run canonical job callbacks,
- perform Brain turns,
- evaluate policy,
- create outbound intents,
- serve local-bridge lease/result endpoints,
- schedule opaque Convex signals.

Vercel must not:
- run Evolution,
- retain WhatsApp session state,
- treat Convex as canonical,
- rely on sticky process memory,
- expose server credentials to browser clients.

## Health

Liveness checks application composition.

Readiness checks required dependencies separately:
- configuration,
- database,
- orchestration,
- model route where the endpoint requires it.

Transport health is separate from Core readiness.

## Database role

Use a server-only pooled Neon runtime credential. Migration credentials remain separate and should not live in Vercel runtime configuration.

## Secrets

Use independent credentials for:
- Convex -> Vercel,
- Vercel -> Convex,
- local bridge -> Vercel.

Do not print or return them.

## Deployment facts

Deployment IDs, aliases, and live readiness results belong in `CURRENT_IMPLEMENTATION.md` or progress records and must be refreshed from the provider before an operational change.
