---
title: "Evolution and WhatsApp Library Security Gate"
document_id: "docs::EVOLUTION_VERSION_GATE"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Status

Fail closed.

Previous repository research identified unsafe or unsuitable Evolution/Baileys combinations and reviewed one development-source contingency. That evidence is historical and must be rechecked before any live pairing because releases and advisories change.

## Required evidence

Before enabling Evolution:

1. choose an exact Evolution source/release,
2. record exact commit/tag,
3. inspect lockfile and exact WhatsApp-library version,
4. check current security advisories and release notes,
5. build or obtain an immutable image,
6. record image digest,
7. confirm adapter endpoints/auth against that exact source,
8. run provider-free and local integration tests,
9. enable only in non-production first,
10. pair only the dedicated JARVIS number.

## Gate inputs

Runtime configuration should bind:
- provider build ID,
- dependency version,
- immutable image digest,
- explicit enable flag,
- environment,
- provider integration opt-in.

Mismatch means disabled.

## No floating images

Never use `latest` or a floating development tag for a paired JARVIS session.

## Sensitive evidence

Keep session files, QR/pairing codes, and secrets outside Git and model context.

## Review rule

This file intentionally avoids declaring a September 2026 dependency safe forever. Re-run the evidence check at pairing time.
