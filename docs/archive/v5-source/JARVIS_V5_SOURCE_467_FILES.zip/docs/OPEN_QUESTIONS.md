---
title: "Owner Decisions and Live Gaps"
document_id: "docs::OPEN_QUESTIONS"
status: "reference"
authority_class: "evidence"
owner_role: "repo_explorer"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Unresolved does not mean freely infer

## Owner enrollment choices

Confirm the proposed runtime budget, optional temporary-override limits, normal interruption profile, actual sleep/quiet policy, step-up duration, finite-lease duration/use caps and Night Mode source/recipient scope before enabling them. Prior $50 interest is recorded separately from a signed current profile. $60 was an assistant suggestion, not approval.

## Repository-dependent unknowns

Local HEAD/dirty state, current migration head, live model route, actual prompt registry consumers, provider readiness, pairing status, repository settings, protected gate identity and signing-key custody require J5-M00/M01 evidence.

## Not open questions

Phase 9 device policy and Phase 11 bounded multi-agent work are wanted future scope and have missions. Night Mode and browser work have named build slots. Mentor/FRIDAY are delivery modes and do not need EDITH authority. Their sequencing is in ROADMAP.json.

A broad request to build JARVIS does not settle an authorization amount, sensitive retention policy or external-message scope. Keep dependent capability blocked and continue independent work.
