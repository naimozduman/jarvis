---
title: "Bounded Source-Backed Context"
document_id: "docs::CONTEXT_ASSEMBLY"
status: "draft"
authority_class: "protected"
owner_role: "memory_architect"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Deterministic selection precedes reasoning

Keep the existing owner-scoped assembler and manifest persistence. Trace maxApproxPromptTokens, record/recent-message caps and excludedRecordCount at actual callers rather than assuming environment variables are unused.

Rank by owner-approved goals, active commitments, source authority, freshness, relevance, conflict and current context. Preserve known, inferred, stale, conflicting, missing and not_connected as epistemic states. Restricted is a sensitivity/access class, not a seventh epistemic value. Both dimensions are present in source records and evaluated before model access.

## Full request budget

Instructions, mandatory policy, message text, context, tool/schema definitions and output reserve all consume capacity. Byte/module guards in the pack only constrain instruction growth. Live runtime tests must protect required instructions, measure provider-token estimates and explicitly record excluded counts by reason. If mandatory context does not fit, fail or reduce optional retrieval. Do not silently drop owner/security scope.

Manifest records selected source IDs and versions, safe content hashes, reasons, stale/redacted state, exclusions, context version and assembled-prompt fingerprint. A model can cite only supplied references. Indexes are derived and obey source deletion/correction propagation.

Acceptance covers oversized source, Unicode/multilingual text, giant schema/tool catalogs, conflicting dates, cross-owner records, stale app summary, revoked source and context budget overflow. Reference pack tests are not a replacement for actual gateway request-size tests.
