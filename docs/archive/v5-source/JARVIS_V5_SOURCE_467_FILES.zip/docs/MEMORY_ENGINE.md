---
title: "Memory Engine V5"
document_id: "docs::MEMORY_ENGINE"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Memory is typed

JARVIS does not maintain one undifferentiated “memory blob.”

Durable types:
- facts,
- preferences,
- people,
- relationships,
- projects,
- observations,
- hypotheses,
- open loops,
- bounded personality traits.

Procedures live in the separate Skill Engine. History lives in Life Ledger. Subjective reflection lives in Journal.

## Candidate pipeline

`evidence -> candidate -> review/promotion -> active memory -> supersession/review`

Candidates retain source, evidence references, confidence, sensitivity, validity interval, review time, and related entities.

## Promotion rules

- Explicit owner statements are strong evidence but still source-backed.
- Model inference does not become a fact automatically.
- Observed behavior stays an observation until promotion criteria are met.
- Preferences need repeated evidence or confirmation.
- External untrusted content cannot directly create owner memory.
- One emotional interaction cannot permanently change personality settings.
- Constitution is never changed through memory promotion.

## Update correctness

Before adding a new memory, retrieve potentially conflicting existing records.

A memory update explicitly chooses:
- add,
- update/supersede,
- deactivate/delete under policy,
- no-op,
- conflict requiring review.

This borrows the useful retrieve-before-write idea from external memory systems without handing them canonical ownership.

## Retrieval

Combine deterministic filters, recency, entity links, and optional semantic search. Return provenance and epistemic type.

## Correction

Owner correction creates a durable supersession/rejection path. Derived summaries/indexes must refresh.

## Memory versus Life Ledger

“What happened on Tuesday” belongs primarily to Ledger/history.

“What is generally true about Naim or an ongoing project” may belong to memory.

## Memory versus skill

“I use this deployment process” is a procedure, not a personal fact.
