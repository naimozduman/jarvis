---
title: "Convex Orchestration"
document_id: "docs::CONVEX_ORCHESTRATION"
status: "draft"
authority_class: "protected"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Role

Convex is an opaque wake-up coordinator.

It is not:
- canonical database,
- Brain,
- message store,
- memory store,
- WhatsApp transport,
- approval store.

Neon remains canonical.

## Allowed data

Convex may store bounded scheduling metadata such as:
- canonical job/delivery ID,
- correlation ID,
- trigger type,
- generation/sequence,
- scheduled time,
- dispatch count,
- safe error category,
- opaque signal state.

## Forbidden data

No:
- message bodies,
- prompts/context,
- constitution,
- memories,
- health/finance records,
- private conversation history,
- provider credentials,
- raw phone/JID,
- WhatsApp session state.

## Job loop

`Neon commit -> Vercel sends opaque schedule -> Convex wakes Vercel -> Vercel rehydrates/leases Neon job -> execute -> persist result -> optional bounded retry schedule`

Generation rejects stale callbacks.

## Local transport signal

`canonical delivery -> opaque Convex signal -> local bridge sees ID/sequence -> bridge asks Vercel for fresh Neon lease/content -> sends locally -> reports result -> canonical state`

Convex never carries private content.

## Authentication

Vercel-to-Convex, Convex-to-Vercel, and local-bridge identities use separate credentials/scopes.

## Failure

If Convex is unavailable, canonical state remains correct. Recovery replays opaque wakeups, not private data.
