---
title: "Start JARVIS V5"
document_id: "START_HERE"
status: "active"
authority_class: "orientation"
owner_role: "architecture_planner"
created_at: "2026-09-26"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Start with the finished V5 pack

Keep this extracted directory beside the existing JARVIS repository. Do not overwrite the live checkout or accept the pack's empty enrollment policies as replacements for installed trust.

## First session

Use [prompts/START_V5_IN_CODEX.txt](prompts/START_V5_IN_CODEX.txt) in a new Codex session after the previous session saves its handoff. Supply the actual extracted-pack and sanitized-repository paths. The first mission inventories and proposes a transition. It does not begin all 24 missions or replace the old code wholesale.

The owner-operated source exporter and isolated worker are in `tools/jarvis-v5/`. The networked reasoning host needs its own credential separation. If that boundary is not available, use sanitized document-only input and do not execute repository code. No software config file proves OS isolation by existing.

## Run pack checks

```sh
python tools/jarvis-v5/validate.py --root .
python -m unittest discover -s tools/jarvis-v5/tests -p 'test_*.py' -v
node --test tools/jarvis-v5/tests/*.test.mjs
```

Full JSON Schema fixtures require the separately pinned `tools/jarvis-v5/requirements-schema.txt` in an isolated test environment. These are pack tests, not the application's database/provider tests.

## What V5 changes

One product-spec source generates the long PRD. A deterministic resolver generates relevant task context. Explicit missions preserve, classify and reconcile existing code. Mission eligibility uses trusted prerequisite receipts. Key-transition tooling has loss/compromise/rotation tests. Runtime contracts remain drafts until a migration proves their producers and consumers.

## Required owner installation

M00 is a sanitized audit, without enrollment. M01 prepares and installs trusted verification, independent key/recovery custody, required merge checks and real isolation evidence. M02 onward needs trusted mission receipts. The supplied signer keys and verifier profiles are intentionally empty. No signing key, provider credential, deployment or budget was configured during packaging.

The focused GitHub source observation is documented in `governance/RECONCILIATION.json`; it is not a local working-tree or deployment audit. Read [VALIDATION_REPORT.md](VALIDATION_REPORT.md) for actual local results and limitations.
