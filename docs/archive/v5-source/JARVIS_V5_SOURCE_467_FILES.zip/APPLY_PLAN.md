---
title: "V5 integration and preservation plan"
document_id: "APPLY_PLAN"
status: "active"
authority_class: "orientation"
owner_role: "release_operator"
created_at: "2026-09-26"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Integrate by plan, not directory overwrite

1. Preserve the real repository checkpoint and dirty work through the owner-operated sanitized export. Do not reset, stash, clean or discard unfinished code.
2. Run J5-M00 using the finished pack as candidate input. Compare focused source observations with actual files and identify changes since the observed commit.
3. Generate `reconcile.py` and `overlay_plan.py` scratch reports. Every collision requires review. New files are candidates, not automatically trusted code.
4. Review V5 product/governance proposals. Preserve existing accepted ADR numbering, applied migrations, active runtime schemas and the old loader until the relevant migration. Do not overwrite existing enrolled trust/evidence/mission policies with disabled examples.
5. Install the trusted gate, verifier and recovery protocol through the separate owner context in M01. Preserve the existing application CI suites. Test rejection and final-current-head admission before treating protection as effective.
6. Adopt the approved tooling/doc changes on a bounded branch. Store the accepted integration plan and source hashes. The builder does not approve its own protected diff.
7. Run the code-reconciliation missions. Each subsystem gets keep/repair/migrate/replace/retire/unresolved with actual tests. Never infer a wholesale rewrite from V5 filenames.

No replacement root package.json, lockfile, workspace file, environment file or Docker service definition is shipped. Integration examples are not automatic configuration. Source research archives and generated previews are supporting inputs, not instructions to import private data or activate a runtime.

V4-to-V5 path removals describe this pack only. Delete no corresponding repository file until its consumers and retention obligations are reviewed. Runtime action authority, code promotion, mission completion and deployment permission are four separate gates.
