---
title: "V5 build order"
document_id: "v5-build-order"
status: "generated"
authority_class: "generated"
owner_role: "architecture_planner"
created_at: "2026-09-26"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Build order

The owning sequence is [ROADMAP](governance/ROADMAP.json). Read [the generated plan](docs/BUILD_PLAN.md) for all 24 missions and [START_HERE](START_HERE.md) for integration.

Preserve the repository, install trust, reconcile existing code, then expand one bounded feature at a time. There is no automatic run-all command. Mission status in a file is descriptive; trusted receipts determine admission.
