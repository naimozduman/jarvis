---
title: "JARVIS V5 engineering pack"
document_id: "README"
status: "active"
authority_class: "orientation"
owner_role: "architecture_planner"
created_at: "2026-09-26"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# JARVIS V5

A versioned engineering pack for evolving the existing JARVIS Personal OS. It contains the product specification, targeted Codex skills and missions, contract drafts, code reconciliation evidence, executable governance tooling and tests. It is not a finished Personal OS application or a replacement monorepo.

Start at [START_HERE.md](START_HERE.md). The complete product direction is in [docs/PRD.md](docs/PRD.md). Routine coding uses bounded packets from `context.py`, not the entire specification every turn.

The 24 missions begin with preservation, trust installation and existing-code reconciliation. Brain and infrastructure repair have their own work orders. Feature tracks then cover first-party access, WhatsApp, memory, domain apps, Android, voice, device policy, executors, workers, Night Mode and browser research.

The supplied trust, mission and key tools do not enroll themselves. `docs/ENFORCEMENT_STATUS.md` distinguishes implemented pack code, reference controls and runtime work still to build. No owner budget, new authority or provider connection is activated.

Do not copy this directory over your live repository. Use the inert per-file plan and preserve enrolled trust, root toolchain configuration, active schemas, accepted ADRs, migrations and dirty work.
