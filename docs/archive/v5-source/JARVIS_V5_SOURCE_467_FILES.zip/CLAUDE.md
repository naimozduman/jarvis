---
title: "Claude-compatible JARVIS entry"
document_id: "CLAUDE"
status: "active"
authority_class: "orientation"
owner_role: "architecture_planner"
created_at: "2026-09-26"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Shared builder instructions

Use `AGENTS.md` as the session entry. Resolve the appropriate task packet and engineering skill. This file creates no separate architecture or authority hierarchy. The same source, evidence, isolation, migration and handoff rules apply regardless of model vendor.

For Convex changes, read the actual generated Convex guidelines from the real repository first. Convex remains the opaque coordinator, not canonical JARVIS private state. Do not copy a generic backend instruction into the product architecture.
