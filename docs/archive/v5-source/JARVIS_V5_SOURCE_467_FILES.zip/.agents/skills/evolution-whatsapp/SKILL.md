---
title: "Maintain the dedicated-account WhatsApp bridge boundary."
document_id: ".agents::skills::evolution-whatsapp::SKILL"
status: "active"
authority_class: "engineering_skill"
owner_role: "integration_specialist"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
name: "evolution-whatsapp"
description: "Maintain the dedicated-account WhatsApp bridge boundary."
version: "5.0.0"
---

# Purpose

Maintain the dedicated-account WhatsApp bridge boundary.

## Scope and handoff

Primary role: `integration_specialist`. Follow AGENTS.md. Another role may consume this playbook but must not silently take promotion authority.

## Workflow
1. Reverify actual upstream advisory, version, license and image evidence.
2. Keep primary personal account unpaired and identify owner through enrollment.
3. Reject untrusted alias/history/protocol ingress.
4. Test uncertain sends, expiry, reconnect and notification-only high-impact approvals.

## Read
- `docs/EVOLUTION_VERSION_GATE.md`
- `docs/WHATSAPP_ARCHITECTURE.md`
- `docs/WHATSAPP_IDENTITY.md`

## Evidence and stop

Use synthetic data and exact current source paths. Report unknowns, omitted tests and observed versions. Write the session handoff to governance/STATE.json. Stop on a protected-rule conflict or missing external authority. Do not change the judge to make the feature pass.
