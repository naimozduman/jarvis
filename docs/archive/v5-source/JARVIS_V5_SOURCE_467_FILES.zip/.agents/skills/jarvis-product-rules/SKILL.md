---
title: "Preserve product invariants without duplicating security policy."
document_id: ".agents::skills::jarvis-product-rules::SKILL"
status: "active"
authority_class: "engineering_skill"
owner_role: "architecture_planner"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
name: "jarvis-product-rules"
description: "Preserve product invariants without duplicating security policy."
version: "5.0.0"
---

# Purpose

Preserve product invariants without duplicating security policy.

## Scope and handoff

Primary role: `architecture_planner`. Follow AGENTS.md. Another role may consume this playbook but must not silently take promotion authority.

## Workflow
1. Own product intent and user experience, not security implementation review.
2. Reference canonical invariant IDs and accepted PRD decisions.
3. Keep goals, observations, moods, plans and actual outcomes distinct.
4. Hand threats/credentials/authorization to security-and-privacy.

## Read
- The selected requirement IDs from `governance/PRODUCT_SPEC.json`; consult the relevant `docs/PRD.md` section only when product scope changes, not the entire file on every task.
- `docs/DOCUMENTATION_GOVERNANCE.md`

## Evidence and stop

Use synthetic data and exact current source paths. Report unknowns, omitted tests and observed versions. Write the session handoff to governance/STATE.json. Stop on a protected-rule conflict or missing external authority. Do not change the judge to make the feature pass.
