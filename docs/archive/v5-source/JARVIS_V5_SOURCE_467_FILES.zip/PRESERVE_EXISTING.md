---
title: "Existing repository preservation"
document_id: "PRESERVE_EXISTING"
status: "draft"
authority_class: "protected"
owner_role: "release_operator"
created_at: "2026-09-26"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Preserve working evidence and code

The V5 pack is not the repository and is not a reset operation. Keep active source, tests, lockfile/toolchain settings, credentials outside Git, applied migrations, accepted ADRs, deployment history and deliberate dirty work.

Do not copy root machine configuration from a prior pack over the repository. No replacement root package.json, lockfile, workspace file, environment file or Docker services is supplied in V5. Integration examples are candidates for review, not commands to run in a privileged environment.

The existing code-based prompt registry and active runtime schemas remain active until an explicit migration proves consumers, producers, compatibility and rollback. Candidate file version numbers do not override that fact.

Use J5-M00 and J5-M02 to classify each subsystem as keep, repair, migrate, replace, retire or unresolved. `tools/jarvis-v5/reconcile.py` only creates a collision/disposition plan from sanitized inputs. It never copies or deletes repository files.

Installed trust policies and public keys must not be overwritten by shipped empty enrollment examples. Original V2/V3/V4 reference material remains historical, with source hashes. V5 path retirements describe this pack's navigation, not permission to delete corresponding live files.

For every eventual replacement, record the exact prior path/hash, consumers, safe rollback, data implications, intended migration, tests and owner-controlled promotion evidence. Preserve uncertainty when the local branch or deployed schema cannot be observed.
