---
title: "V5 source and evidence index"
document_id: "SOURCE_INDEX"
status: "draft"
authority_class: "protected"
owner_role: "docs_researcher"
created_at: "2026-09-26"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

# Source index

## Source-derived product and research

The original PRD V2 document, two JARVIS research PDFs and Muse research text are preserved under `reference/source/`. Their byte hashes are in `reference/source/SOURCE_MANIFEST.json`. The extracted PRD text is for navigation; the original document is the evidence for layout and tables.

`governance/PRODUCT_SPEC.json` attributes the origin of each V5 product section and generates docs/PRD.md. `docs/research/2026-09-external-build-lessons.md` preserves component lessons and limitations. Creator claims are not converted into verified JARVIS capabilities.

## Focused repository reads

`governance/RECONCILIATION.json` records the pinned repository checkpoint, six inspected code/workflow paths, exact Git blob hashes and proposed dispositions. `docs/CURRENT_IMPLEMENTATION.md` explains the evidence boundary. These reads are not a full clone audit or a local dirty-tree inspection.

## Current official supplementary references

`governance/RESEARCH_SOURCES.json` lists the official documentation inspected for Codex skill/config interfaces, GitHub privileged workflow boundaries, PostgreSQL time semantics and key lifecycle guidance. URLs are navigation sources, not copied licenses or guarantees about live service configuration. Recheck provider-specific behavior at the associated mission.

## Historical pack evidence

`governance/VERSION_TRANSITION.json` links the V4.1 source archive to this generation. `reference/v4.1/validation/` holds that release's original local test records. Only the current VALIDATION_REPORT reports V5 execution. Passing checksums establish bytes, not semantic truth.
