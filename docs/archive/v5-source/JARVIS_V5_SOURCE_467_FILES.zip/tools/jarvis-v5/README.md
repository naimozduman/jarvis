---
title: "V5 Governance Tools"
document_id: "tools::jarvis-v4::README"
status: "draft"
authority_class: "orientation"
owner_role: "governance_reviewer"
created_at: "2026-09-25"
reviewed_at: null
review_evidence: null
review_triggers: ["scope_change", "contract_change"]
pack_version: "5.0.0"
---

## Requirements and local checks

Use Node 22+ and Python 3.11+. These standalone tools do not change the application package.json, lockfile, workspace configuration or provider credentials.

```sh
python tools/jarvis-v5/validate.py --root .
python -m unittest discover -s tools/jarvis-v5/tests -p 'test_*.py' -v
node --test tools/jarvis-v5/tests/*.test.mjs
```

For complete JSON Schema validation in an isolated environment:

```sh
python -m venv /absolute/scratch/jarvis-schema-venv
/absolute/scratch/jarvis-schema-venv/bin/python -m pip install -r tools/jarvis-v5/requirements-schema.txt
/absolute/scratch/jarvis-schema-venv/bin/python -m unittest discover -s tools/jarvis-v5/schema_tests -v
```

On Windows use the environment's Scripts/python.exe. The basic validator checks schema identities and references; it is not a general JSON Schema engine. Full fixture tests use jsonschema with a closed local registry, not network resolution.

## Generated artifacts

After an authorized edit, run render.py, compile_prompts.py and index.py in that order. The compiler writes previews, not live prompts.

```sh
python tools/jarvis-v5/render.py --root .
python tools/jarvis-v5/compile_prompts.py --root . --out generated/prompts
python tools/jarvis-v5/index.py --root .
python tools/jarvis-v5/validate.py --root .
```

index.py is a pack/managed-file tool, not permission to hash private application files. After repository integration, use `index.py --root . --managed`, with explicit `--add relative/path` for new reviewed artifacts, instead of sweeping .env or live data into the index. The tool refuses a default sweep when apps/ or packages/ exists. The trusted gate, not a regenerated candidate checksum, decides authority.

## Safe repository integration

```sh
python /absolute/path/to/pack/tools/jarvis-v5/overlay_plan.py --pack /absolute/path/to/pack --repo /absolute/path/to/jarvis --output /absolute/scratch/overlay-plan.json
```

The planner is read-only. It checks the repository marker files, dirty state, old ADR presence and each candidate path. It does not copy files, apply migrations, install tools or stage changes.

## Trusted exact-change gate

Run trust-gate.mjs from a trusted baseline or separate owner-controlled checkout. Supply a full base/head SHA, accepted policy and enrolled public key. Candidate code is never imported. Existing history rewrites fail even with a normal promotion signature. New accepted decisions append.

The gate protects ordinary code by default. Only narrow base-owned inert evidence paths are exempt from owner signatures. Independent candidate tests and review remain required. Filesystem restrictions, builder credential reachability, GitHub bypass settings and key custody remain operator setup.

## Owner signatures, not builder credentials

Owner-only bootstrap creates keys outside any builder-readable filesystem or account. A tool flag is not an access-control boundary.

```sh
node tools/jarvis-v5/owner-signing.mjs keygen --directory /owner-only/jarvis-key --confirm-owner-custody
```

Register the printed public key ID in the accepted TRUST_POLICY and install only the public PEM as governance/owner-public.pem. No real keys ship in the pack. The owner reviews the exact diff and uses the signing tool's sign command with base/head/policy/private-key/output and --i-reviewed-exact-diff. Store the receipt outside the signed commit to avoid a self-referential head SHA.

Key rotation is itself a protected change. A compromised signing key or trusted runner invalidates this boundary. The pack does not prevent the ultimate owner/admin from deliberately removing protections.

## What each tool checks

validate.py: metadata, local links, all-file pack index, hashes, role/skill wiring, roadmap dependencies, draft identities, generated prompt previews and simple direct-import fences.

impact.py: changed code paths mapped to owning docs and test areas. A no-contract-impact reason is permitted for refactors. Exact-head test references must be verified by independent CI; the script cannot authenticate an arbitrary run URL.

review_evidence.py: missing/stale observations, review dates without evidence and resolved incidents without regression linkage. --require blocks only operations depending on those observations.

env_report.py: heuristic environment-key inventory versus the real .env.example. Dynamic access and provider-injected variables require review. Do not call this a complete compiler-based proof.

git_snapshot.py: bounded Git blob extraction without checkout filters, archive exclusions, symlinks or submodules. The candidate is inert data.

github_candidate.py: read-only same-repository PR object fetch and detached JSON receipt collection. It never prints credentials or executes comment text.

reference_controls.py: tested example semantics for action binding, finite leases, spending admission, keyed identity references and cancellation. It is not the production database/auth/executor implementation.

version_gate.py: rejects a registered prompt or contract byte change without a version change relative to trusted base. It checks a version transition, not semantic compatibility.

## Known limits

The tools do not prove semantic documentation consistency, adequate judgment, complete dynamic import discovery, atomic production budget reservation or live shutdown behavior. See docs/ENFORCEMENT_STATUS.md for adoption gates. Do not weaken a validator to turn an unavailable provider or unexecuted test into success.

## V5 commands

These V4.1 enforcement mechanisms are retained under tools/jarvis-v5. Read docs/BUILDER_ISOLATION.md and docs/VERIFICATION_EVIDENCE.md for their exact authority boundaries.

- `prepare_builder.py --repo PATH --commit SHA --out FRESH_PATH`: owner-side read-only committed source export, with dirty/omission report and no Git credential/history copy.
- `isolated_worker.py --prepared PATH --pack TRUSTED_PATH --out FRESH_PATH --image IMAGE@sha256:DIGEST --mode audit --probe`: rootless Linux offline worker and dummy probe. Requires installed image/daemon. No host fallback.
- `trust-gate.mjs --repo PATH --base SHA --head SHA --policy TRUSTED_POLICY --inspect-only`: mode-aware classification only, explicitly not authorization; safe for M00 before enrollment.
- `evidence-signing.mjs verify --policy TRUSTED_POLICY --record RECEIPT`: exact purpose/subject/key/time verification. The separate sign command requires owner-side private key and explicit verification flag.
- `promotion_evidence.py --trusted-root BASE --candidate-root INERT_HEAD --repo OBJECT_REPO --base SHA --head SHA --evidence RECEIPTS --plan-only`: selected required eval coverage without promotion. Remove plan-only for signed/fresh evidence and live metadata admission. Actual admission requires a read-only GH_TOKEN in the trusted process.
- `impact.py` accepts `--policy BASE_TRUST_POLICY` to reuse exact-tree mode-aware operational exceptions. This tool alone still does not authenticate run references.

GitHub workflow example runs these from accepted BASE, not candidate files. It does not install an external recorder or final merge controller. Current-head, non-expired evidence must be rechecked at final promotion. No production credentials belong in candidate tests.

`review_evidence.py` remains a warning/reporting utility. It has not silently become an all-project freshness gate. The selected signed requirement gate is promotion_evidence.py.

## V5 integration entrypoints

- `generate.py --root PACK` rebuilds the PRD, roadmap, handoff, enforcement view, requirement trace and managed artifact lifecycle. It refuses a full application tree unless `--managed` selects an existing reviewed index.
- `context.py --root PACK --topic memory --output SCRATCH` produces a bounded, hash-addressed builder context, not a runtime prompt or permission.
- `reconcile.py --pack PACK --source SANITIZED_SOURCE --output SCRATCH/plan.json` lists pinned-source matches and per-file collisions without changing the source.
- `mission_runner.py --trusted-root TRUSTED_PACK --policy POLICY --receipts RECEIPTS --mission J5-M02 --mode implementation --repo SANITIZED_GIT --head SHA --output SCRATCH` first calls the Node admission gate and only then exports mission context. It executes no implementation command. The trusted controller must make this the work-entry requirement. A builder-owned copy does not constrain the builder's shell.
- `mission_gate.mjs` verifies exact mission definitions, signed prerequisites, epoch, validity and checkpoint ancestry. `audit` only admits J5-M00 and `bootstrap-preparation` only admits J5-M01. Both are narrow non-implementation modes.
- `key_lifecycle.mjs` verifies public-state rotation, loss, compromise and emergency revocation requests. It writes proposed public state only. External atomic installation and recovery custody remain operator duties.
- `state.py` writes only the descriptive handoff with an expected-content hash and a local cooperating-process lock.
- `retirement.py` validates a removal proposal. It never deletes or trusts a supplied evidence reference as an authenticated review.
- `trusted_time.py` contains reference deadline checks, not a live clock attestation.

V5 signatures deliberately use a different purpose/domain from retained repository-change and V4.1 evidence protocols. Do not substitute one signature type for another. Newly generated dummy keys are test material only and never an installed owner.

Refresh order after authorized source changes: `generate.py`, `compile_prompts.py --root PACK --out PACK/generated/prompts`, `index.py`, `validate.py`. Full schema validation is a separate test suite. Actual commands and limits are recorded in VALIDATION_REPORT.

`owner_record_signing.mjs` is a separate owner/verifier-side command. Without a private key it previews the canonical public payload and digest. Signing requires an exact `--confirm-digest`, the correct purpose, an isolated private-key path and a new output file. See KEY_LIFECYCLE and MISSION_ADMISSION for the commands. It does not attest that supplied evidence is true or install any trust state.
